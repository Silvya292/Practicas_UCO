from select import select
import sys
import controllerTableCalifications as controller

from PyQt5.QtWidgets import QWidget, QTreeView, QFileSystemModel, QApplication, QLabel, QLineEdit, QTextEdit, QVBoxLayout, QHBoxLayout, QPushButton, QGridLayout, QTableWidget, QTableWidgetItem


class TableCalificationsDlg(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):

        self.table1 = QTableWidget(0, 2)
        self.table1.setHorizontalHeaderLabels(['Nombre', 'Notas'])
        
        self.table2 = QTableWidget(0, 2)
        self.table2.setHorizontalHeaderLabels(['Nombre', 'Notas'])

        self.ordButton = QPushButton("Ordenar")
        self.selectButton = QPushButton("Seleccionar Aprobados")

        self.addButton = QPushButton("Añadir")
        self.deleteButton = QPushButton("Borrar")

        self.saveButton = QPushButton("Guardar")
        self.openButton = QPushButton("Abrir")

        grid = QGridLayout()
        grid.setSpacing(10)

        grid.addWidget(self.ordButton, 2, 0)
        grid.addWidget(self.selectButton, 2, 1)

        grid2 =QGridLayout()
        grid2.setSpacing(10)

        grid2.addWidget(self.addButton, 2, 2)
        grid2.addWidget(self.deleteButton, 2, 3)

        grid3 = QGridLayout()
        grid3.setSpacing(10)

        grid3.addWidget(self.saveButton, 2, 3)
        grid3.addWidget(self.openButton, 2, 4)

        layout = QGridLayout()
        layout.addWidget(QLabel("Lista de Notas"), 0, 0)
        layout.addWidget(QLabel("Lista de Aprobados"), 0, 1)
        layout.addWidget(self.table1, 1, 0)
        layout.addWidget(self.table2, 1, 1)
        layout.addLayout(grid, 2, 0)
        layout.addLayout(grid2, 3, 0)
        layout.addLayout(grid3, 2, 1)
        
        self.setLayout(layout)

        self.setGeometry(300, 300, 550, 400)
        self.setWindowTitle('Lista de Alumnos')
        self.show()

        self.ordButton.clicked.connect(self.ordAlumnos)
        self.selectButton.clicked.connect(self.selectAlumnos)
        self.addButton.clicked.connect(self.addAlumnos)
        self.deleteButton.clicked.connect(self.deleteAlumnos)
        self.saveButton.clicked.connect(self.saveAs)
        self.openButton.clicked.connect(self.openFile)

    def ordAlumnos(self):
        controller.eventOrdAlumnos(self)

    def selectAlumnos(self):
        controller.eventSelectAlumnos(self)

    def addAlumnos(self):
        controller.eventAddAlumnos(self)

    def deleteAlumnos(self):
        controller.eventDeleteAlumnos(self)

    def saveAs(self):
        controller.eventSaveAs(self)

    def openFile(self):
        controller.eventOpenFile(self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    form = TableCalificationsDlg()
    sys.exit(app.exec_())