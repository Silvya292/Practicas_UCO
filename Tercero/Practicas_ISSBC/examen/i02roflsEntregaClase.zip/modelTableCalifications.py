from pathlib import Path
from PyQt5.QtWidgets import (QFileDialog)
import sys
from PyQt5.QtWidgets import QWidget, QTreeView, QFileSystemModel, QApplication, QLabel, QLineEdit, QTextEdit, QVBoxLayout, QHBoxLayout, QPushButton, QGridLayout, QTableWidget, QTableWidgetItem

def ordAlumnos(self):
    self.table1.sortItems(0, 0)

def selectAlumnos(self):
    for row in self.table1.selectionModel().selectedRows():
        if row.row() not in self.table2.selectionModel().selectedRows():
            self.table2.insertRow(row.row())
            self.table2.setItem(row.row(), 0, QTableWidgetItem(self.table1.item(row.row(), 0).text()))
            self.table2.setItem(row.row(), 1, QTableWidgetItem(self.table1.item(row.row(), 1).text()))
            self.table1.removeRow(row.row())

def addAlumnos(self):
    row_count = self.table1.rowCount()
    self.table1.insertRow(row_count)

def deleteAlumnos(self):
    row = self.table1.currentRow()
    self.table1.removeRow(row)

def saveAs(self):
    home = str(Path.home())
    newFileName = QFileDialog.getSaveFileName(self, "Save File", home)
    if newFileName[0]:
        self.fileName = newFileName
        f = open(self.fileName[0], "w")
        filedata = self.textEdit.toPlainText()
        f.write(filedata)
        f.close()

def openFile(self):
    home_dir = str(Path.home())
    fname = QFileDialog.getOpenFileName(self, 'Abrir archivo', home_dir)
    if fname[0]:
        f = open(fname[0], 'r')
        with f:
            data = f.read()